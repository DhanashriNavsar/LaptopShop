import { Check } from './check';

describe('Check', () => {
  it('should create an instance', () => {
    expect(new Check()).toBeTruthy();
  });
});
