export class Check {
    userId!:string;
    first!:string;
    last!:string;
    email!:string;
    phone!:string;
    city!:string;
    postalcode!:string;
    address!:string;
}
